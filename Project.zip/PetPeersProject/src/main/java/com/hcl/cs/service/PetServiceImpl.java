package com.hcl.cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.cs.dao.PetRepository;
import com.hcl.cs.dao.UserRepository;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;

@Service
public class PetServiceImpl {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PetRepository petRepository;

	
	public User getUserByUserName(String userName) {
		return userRepository.getByUserName(userName);
	}

	public void saveUserDetails(String name, String password) {
		User user = new User();
		user.setUserName(name);
		user.setUserPassword(password);
		userRepository.save(user);
	}

	public Boolean validateLoginCreds(String name, String password) {
		User user = userRepository.getByUserName(name);
		return (user!=null && password.equals(user.getUserPassword())) ? true : false;
	}
	
	public Boolean checkDuplicateLoginCreds(String name) {
		User user = userRepository.getByUserName(name);
		return (user!=null) ? false : true;
	}
	public void savePetDetails(String name, String age, String place, String loginUser) {
		Pet pet = new Pet();
		pet.setPetName(name);
		pet.setPetAge(age!=null ? Integer.valueOf(age):0);
		pet.setPetPlace(place);
		//pet.setPetOwnerId(userRepository.getByUserName(loginUser).getUserId());
		petRepository.save(pet);
	}
	
	
	
	
	
	
	
	
	
	
	
	public void buyPetDetails(long petId, String loginUser) {
		
		
		
		System.out.println("entered into buyPetDetails");
		
		Pet pet = petRepository.findByPetId(petId);
		
		pet.setPetOwnerId(userRepository.getByUserName(loginUser).getUserId());
		
		petRepository.save(pet);
		
		System.out.println("pet with id = "+petId+" : "+petRepository.findByPetId(petId));
		
		System.out.println("user id = "+userRepository.getByUserName(loginUser).getUserId());
		
		
		System.out.println("completed buy buyPetDetails");
		
	}
	
	
	
	
	
	
	
	
	
	
	
	

	public List<Pet> getPetList() {
		return petRepository.findAll();
	}

	public List<Pet> getPetList(String loginUser) {
		return petRepository.getByPetOwnerId(userRepository.getByUserName(loginUser).getUserId());
	}
}
