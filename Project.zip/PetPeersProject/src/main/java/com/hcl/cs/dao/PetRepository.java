package com.hcl.cs.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.cs.model.Pet;
import com.hcl.cs.model.User;

@Repository
public interface PetRepository extends JpaRepository<Pet, Long> {
	List<Pet> getByPetOwnerId(Long ownerId);
	Pet findByPetId(long petId);
}
