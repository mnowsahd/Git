
package com.hcl.cs.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.cs.model.Pet;
import com.hcl.cs.service.PetServiceImpl;

@Controller
public class UserLoginController {

	@Autowired
	private PetServiceImpl serviceImpl;
	
	private String loginUser = "";

	@PostMapping("/doLogin")
	public ModelAndView response(@RequestParam("Name") String name, @RequestParam("password") String password) {
		ModelAndView mv = new ModelAndView();
		System.out.println("UserLogincontroller :: response :: user :" + name + " , password : " + password);
		Boolean loginStatus = serviceImpl.validateLoginCreds(name, password);
		if (loginStatus) {
			mv.setViewName("petListPage");
			List<Pet> petList = serviceImpl.getPetList();
			mv.addObject("petList", petList);
			mv.addObject("loginUser", name);
			loginUser = name;
			mv.addObject("msg", "you have successfully logged In");
		} else {
			mv.setViewName("loginPage");
			mv.addObject("msg", "Please check the credentials");
		}
		return mv;
	}

	@GetMapping("/doLogin")
	public ModelAndView goLogin() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("loginPage");
		mv.addObject("msg", "");
		return mv;
	}

	@PostMapping("/doRegistration")
	public ModelAndView doRegistration(@RequestParam("name") String name, @RequestParam("password") String password,
			@RequestParam("conformPassword") String conformPassword) {

		ModelAndView mv = new ModelAndView();
		System.out.println("UserLogincontroller :: response :: user :" + name + " , password : " + password
				+ " , conformPassword : " + conformPassword);
		Boolean duplicateLogins = serviceImpl.checkDuplicateLoginCreds(name);
		if(duplicateLogins) {
			serviceImpl.saveUserDetails(name, password);
			System.out.println("UserLogincontroller");
			mv.addObject("msg", "Congratulations.. you have successfully registered with this user name :" + name
					+ ", please login below.");
			mv.setViewName("loginPage");
		} else {
			mv.addObject("msg", "Some one already registered with this username:" + name+ ", so please try with other username !!");
			mv.setViewName("registrationPage");
		}
		return mv;
	}
	
	@GetMapping("/doAdd")
	public ModelAndView goAdd() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("addPetPage");
		return mv;
	}
	
	@PostMapping("/doadd")
	public ModelAndView doadd(@RequestParam("name") String name, @RequestParam("age") String age,
			@RequestParam("place") String place) {

		ModelAndView mv = new ModelAndView();
		System.out.println("UserLogincontroller :: response :: pet :" + name + " , Age : " + age
				+ " , Place : " + place);
			serviceImpl.savePetDetails(name, age ,place,loginUser);
			System.out.println("UserLogincontroller");
		 
			mv.setViewName("addPetPage");
			mv.addObject("msg","Congratulation! you hare successfully added your pet Named : "+name+" & Age is : "+age );
			
			
		return mv;
	}
	
	
	
	


	
	
	@PostMapping("/dobuy")
	public ModelAndView dobuy(@RequestParam("petId") long petId) {

		ModelAndView mv = new ModelAndView();
			serviceImpl.buyPetDetails(petId, loginUser);
			mv.setViewName("myPetsPage");
			List<Pet> petList = serviceImpl.getPetList(loginUser);
			mv.addObject("petList", petList);
			mv.setViewName("myPetsPage");			
			System.out.println("completed dobuy");
			mv.addObject("msg","Congratulation! pet brought successfully");
			return mv;
	}
	@GetMapping("/petList")
	public ModelAndView gopetList() {
		ModelAndView mv = new ModelAndView();
		List<Pet> petList = serviceImpl.getPetList();
		mv.addObject("petList", petList);
		mv.setViewName("petListPage");
		return mv;
	}
	
	@GetMapping("/logOut")
	public ModelAndView logOut() {
		loginUser = "";
		ModelAndView mv = new ModelAndView();
		mv.setViewName("loginPage");
		mv.addObject("msg", "");
		return mv;
	}
	
	@GetMapping("/myPetList")
	public ModelAndView myPetList() {
		ModelAndView mv = new ModelAndView();
		List<Pet> petList = serviceImpl.getPetList(loginUser);
		mv.addObject("petList", petList);
		mv.setViewName("myPetsPage");
		return mv;
	}

}
