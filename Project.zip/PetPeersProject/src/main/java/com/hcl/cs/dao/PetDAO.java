package com.hcl.cs.dao;

import java.util.List;

import com.hcl.cs.model.Pet;

public interface PetDAO {
	public abstract List<Pet> getAllPets();

	public abstract List<Pet> getMyPets(int integer);

	public abstract Pet savePet(Pet pet);

	public abstract Pet buyPet(int a, int b);

}