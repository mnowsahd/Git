function validateFields()
{
	let userName=document.getElementById("username").value;
    let password=document.getElementById("password").value;
    
    if(userName=="")
	{
		swal({
			title : "Error",
			text : "Username and Password is mandatory",
			icon : "error"
		});
		return false;
	}
    
    if(password=="")
	{
		swal({
			title : "Error",
			text : "Password is mandatory",
			icon : "error"
		});
		return false;
	}

	 if(userName.length<4 || userName.length>25)
		{
		  swal({
			title : "Error",
			text : "Username length should be in between 4-25",
			icon : "error"
		   });
		 return false;
		}
	 else
     {
		 return true;
     }
}