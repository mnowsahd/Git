function validateForm()
{

	let petName=document.getElementById("petname").value;
	let petAge=document.getElementById("petage").value;
	let petPlace=document.getElementById("petplace").value;
	
	if(petName=="")
	{
		swal({
			title : "Error",
			text : "All fields are mandatory",
			icon : "error"
		});
		return false;
		
	}
	
	if(petAge=="")
	{
		swal({
			title : "Error",
			text : "Age is mandatory",
			icon : "error"
		});
		return false;
		
	}
	
	if(petPlace=="")
	{
		swal({
			title : "Error",
			text : "Place is mandatory",
			icon : "error"
		});
		return false;
		
	}
	
	if(parseInt(petAge)<0 || parseInt(petAge)>16)
	{
		swal({
			title : "Error",
			text : "Age should be 1 and 16 years",
			icon : "error"
		});
		return false;
	
	}
	else
	{
		return true;
	}
}