function validateForm()
{
	let userName=document.getElementById("username").value;
	let password=document.getElementById("password").value;
	let confirmPassword=document.getElementById("cnfpassword").value;
	
	if(userName=="")
	{
		swal({
			title : "Error",
			text : "All fields are mandatory",
			icon : "error"
		});
		return false;
	}
	
	if(password=="")
	{
		swal({
			title : "Error",
			text : "Password is mandatory",
			icon : "error"
		});
		return false;
	}
	
	if(confirmPassword=="")
	{
		swal({
			title : "Error",
			text : "Confirm Password is mandatory",
			icon : "error"
			});
				return false;
			}
				 
	
	 if(userName.length<4 || userName.length>25)
		{
		  swal({
			title : "Error",
			text : "Username length should be in between 4-25",
			icon : "error"
		   });
		 return false;
		}
	if(password!=confirmPassword)
	{
		swal({
			title : "Error",
			text : "Password not match",
			icon : "error"
		   });
		 return false;
	}
	
	 if(checkPasswordStrength(password))
	{
		swal({
			title : "Error",
			text : "Password is not strong enough",
			icon : "error"
		});
		return false;
	}
	else
	{
		return true;
	}

	
}
function checkPasswordStrength(password)
{
	if(password.length<8)
		{
		  return true;
		}
	else
	{
		var capitalLetterCount=0;
		var smallLetterCount=0;
		var numbersCount=0;
		var specialCharCount=0;
		
		for(i=0;i<password.length;i++)
		{
			if(password.charAt(i)>='A' && password.charAt(i)<='Z')
			 {
				capitalLetterCount++;
			 }
			else if(password.charAt(i)>='a' && password.charAt(i)<='z')
			{
				 smallLetterCount++;	
			}
			else if(password.charAt(i)>=0 && password.charAt(i)<=9)
			{
				numbersCount++;
			}
			else if(password.charAt(i)=='!'||password.charAt(i)=='@'||password.charAt(i)=='#'||password.charAt(i)=='$'||password.charAt(i)=='%'||password.charAt(i)=='&'||password.charAt(i)=='*')
			{
				specialCharCount++;
			}
		}
		
		if(capitalLetterCount<1 || smallLetterCount<1 || numbersCount<1 || specialCharCount<1)
		{
			return true;
		}
	}
}
