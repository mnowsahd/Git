package com.main.dao;

import java.util.List;

import com.main.model.Pet;
import com.main.model.User;

public interface PetDao {

	public List<Pet> getAllPets();
	
	public void savePet(Pet pet);
}
