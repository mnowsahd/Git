package com.main.service;

import com.main.appexception.ApplicationException;
import com.main.model.User;

public interface LoginService {

	public User validateUser(User user) throws ApplicationException;
}
