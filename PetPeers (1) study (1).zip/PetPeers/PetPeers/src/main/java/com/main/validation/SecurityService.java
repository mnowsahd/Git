package com.main.validation;
import com.main.appexception.ApplicationException;
import com.main.model.User;

public interface SecurityService {

	public boolean validateUser(User user) throws ApplicationException;
	public boolean isPasswordNotStrong(String password) throws ApplicationException;
}
