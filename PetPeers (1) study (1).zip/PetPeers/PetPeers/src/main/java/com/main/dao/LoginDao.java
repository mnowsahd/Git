package com.main.dao;

import com.main.appexception.ApplicationException;
import com.main.model.User;

public interface LoginDao {

	public User validateUser(User user) throws ApplicationException;
}
