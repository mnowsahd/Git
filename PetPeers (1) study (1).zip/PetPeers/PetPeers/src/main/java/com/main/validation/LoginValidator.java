package com.main.validation;

import com.main.appexception.ApplicationException;
import com.main.model.User;

public interface LoginValidator {
 
	 public boolean validateUserLogin(User user) throws ApplicationException;
}
