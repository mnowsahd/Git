package com.main.validation;

import com.main.appexception.ApplicationException;
import com.main.model.Pet;

public interface PetValidator {
	
	public void validatePet(Pet pet) throws ApplicationException;
}
